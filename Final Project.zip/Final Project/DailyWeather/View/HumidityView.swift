//
//  HumidityView.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 20.12.21.
//

import UIKit

class HumidityView: DesignView {
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var humidityLabel: UILabel!
    
    @IBOutlet weak var humidityTopLabel1: UILabel!
    @IBOutlet weak var humidityTopLabel2: UILabel!
    @IBOutlet weak var humidityTopLabel3: UILabel!
    @IBOutlet weak var humidityTopLabel4: UILabel!
    @IBOutlet weak var humidityTopLabel5: UILabel!
    
    
    @IBOutlet weak var humidityBottomLabel1: UILabel!
    @IBOutlet weak var humidityBottomLabel2: UILabel!
    @IBOutlet weak var humidityBottomLabel3: UILabel!
    @IBOutlet weak var humidityBottomLabel4: UILabel!
    @IBOutlet weak var humidityBottomLabel5: UILabel!
    
    func clear() {
        let secondLabels = [humidityTopLabel1, humidityTopLabel2, humidityTopLabel3, humidityTopLabel4, humidityTopLabel5, humidityBottomLabel1, humidityBottomLabel2, humidityBottomLabel3, humidityBottomLabel4, humidityBottomLabel5]
        
        for label in secondLabels {
            label?.text = ""
        }
        
    }
    
    func updateViewForToday(_ hourly: [Hourly]) {
        updateHours(hourly: hourly)
    }
    
    func updateViewForWeekly(_ daily: [Daily]) {
        updateDays(daily: daily)
    }
    
    func getSelectedTitle() -> String {
        let index = segmentedControl.selectedSegmentIndex
        let title = segmentedControl.titleForSegment(at: index) ?? ""
        
        return title
        
    }
    
    func updateHours(hourly: [Hourly]) {
        let topLabels = [humidityTopLabel1, humidityTopLabel2, humidityTopLabel3, humidityTopLabel4,
                         humidityTopLabel5],
            bottomLabels = [humidityBottomLabel1, humidityBottomLabel2, humidityBottomLabel3,
                            humidityBottomLabel4, humidityBottomLabel5]
        
        for i in 0...4 {
            
            let hour = hourly[i + 1]
            let date = Date(timeIntervalSince1970: Double(hour.dt))
            let hourString = Date.getHourFrom(date: date)
            let humidityData = hour.humidity
            
            topLabels[i]?.text = hourString
            bottomLabels[i]?.text = "\(humidityData) %"
        }
        
    }
    
    func updateDays(daily: [Daily]) {
        let topLabels = [humidityTopLabel1, humidityTopLabel2, humidityTopLabel3, humidityTopLabel4,
                         humidityTopLabel5],
            bottomLabels = [humidityBottomLabel1, humidityBottomLabel2, humidityBottomLabel3,
                            humidityBottomLabel4, humidityBottomLabel5]
        
        for i in 0...4 {
            
            let day = daily[i + 1]
            let date = Date(timeIntervalSince1970: Double(day.dt))
            let dayString = Date.getDayOfWeekFrom(date: date)
            let humidityData = day.humidity
            
            topLabels[i]?.text = dayString
            bottomLabels[i]?.text = "\(humidityData) %"
        }
    }
    
}


