//
//  StartViewController.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 20.12.21.
//

import UIKit

class StartViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    
    private let welcomeText = NSLocalizedString("welcome_message_key", comment: "")
    private let startText = NSLocalizedString("start_button_key", comment: "")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        welcomeLabel.text = welcomeText
        startButton.setTitle(startText, for: .normal)
        
    }
    
    
    @IBAction func forStartButton(_ sender: Any) {
        let weatherViewController = storyboard?.instantiateViewController(withIdentifier: "weather") as! MainWeatherViewController
        
        navigationController?.pushViewController(weatherViewController, animated: true)
    }
}

