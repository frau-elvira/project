//
//  CloudsView.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 21.12.21.
//

import UIKit

class CloudsView: DesignView {
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var cloudsLabel: UILabel!
    
    @IBOutlet weak var CloudsTopLabel1: UILabel!
    @IBOutlet weak var CloudsTopLabel2: UILabel!
    @IBOutlet weak var CloudsTopLabel3: UILabel!
    @IBOutlet weak var CloudsTopLabel4: UILabel!
    @IBOutlet weak var CloudsTopLabel5: UILabel!
    
    @IBOutlet weak var CloudsBottomLabel1: UILabel!
    @IBOutlet weak var CloudsBottomLabel2: UILabel!
    @IBOutlet weak var CloudsBottomLabel3: UILabel!
    @IBOutlet weak var CloudsBottomLabel4: UILabel!
    @IBOutlet weak var CloudsBottomLabel5: UILabel!
    
    func clear() {
        let secondLabels = [CloudsTopLabel1, CloudsTopLabel2, CloudsTopLabel3, CloudsTopLabel4, CloudsTopLabel5, CloudsBottomLabel1, CloudsBottomLabel2, CloudsBottomLabel3, CloudsBottomLabel4, CloudsBottomLabel5]
           
        for label in secondLabels {
            label?.text = ""
        }
       
    }
    
    func updateViewForToday(_ hourly: [Hourly]) {
        updateHours(hourly: hourly)
    }
    
    func updateViewForWeekly(_ daily: [Daily]) {
        updateDays(daily: daily)
    }
    
   func getSelectedTitle() -> String {
      let index = segmentedControl.selectedSegmentIndex
      let title = segmentedControl.titleForSegment(at: index) ?? ""
        
       return title
        
   }
    
    func updateHours(hourly: [Hourly]) {
        let topLabels = [CloudsTopLabel1, CloudsTopLabel2, CloudsTopLabel3, CloudsTopLabel4,
                         CloudsTopLabel5],
            bottomLabels = [CloudsBottomLabel1, CloudsBottomLabel2, CloudsBottomLabel3,
                            CloudsBottomLabel4, CloudsBottomLabel5]
       
        for i in 0...4 {
            
            let hour = hourly[i + 1]
            let date = Date(timeIntervalSince1970: Double(hour.dt))
            let hourString = Date.getHourFrom(date: date)
            let cloudsData = hour.clouds
            
            topLabels[i]?.text = hourString
            bottomLabels[i]?.text = "\(cloudsData) %"
        }
        
    }
    
    func updateDays(daily: [Daily]) {
        let topLabels = [CloudsTopLabel1, CloudsTopLabel2, CloudsTopLabel3, CloudsTopLabel4,
                         CloudsTopLabel5],
            bottomLabels = [CloudsBottomLabel1, CloudsBottomLabel2, CloudsBottomLabel3,
                            CloudsBottomLabel4, CloudsBottomLabel5]
       
        for i in 0...4 {
            
            let day = daily[i + 1]
            let date = Date(timeIntervalSince1970: Double(day.dt))
            let dayString = Date.getDayOfWeekFrom(date: date)
            let cloudsData = day.clouds
            
            topLabels[i]?.text = dayString
            bottomLabels[i]?.text = "\(cloudsData) %"
        }
    }
   
}






    
    
    
    
