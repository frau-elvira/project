//
//  FeelsLikeView.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 21.12.21.
//

import UIKit

class FeelsLikeView: DesignView {
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var feelsLikeLabel: UILabel!
    
    @IBOutlet weak var FeelsLikeTopLabel1: UILabel!
    @IBOutlet weak var FeelsLikeTopLabel2: UILabel!
    @IBOutlet weak var FeelsLikeTopLabel3: UILabel!
    @IBOutlet weak var FeelsLikeTopLabel4: UILabel!
    @IBOutlet weak var FeelsLikeTopLabel5: UILabel!
    
    @IBOutlet weak var FeelsLikeBottomLabel1: UILabel!
    @IBOutlet weak var FeelsLikeBottomLabel2: UILabel!
    @IBOutlet weak var FeelsLikeBottomLabel3: UILabel!
    @IBOutlet weak var FeelsLikeBottomLabel4: UILabel!
    @IBOutlet weak var FeelsLikeBottomLabel5: UILabel!
    
    func clear() {
        let secondLabels = [FeelsLikeTopLabel1, FeelsLikeTopLabel2, FeelsLikeTopLabel3, FeelsLikeTopLabel4, FeelsLikeTopLabel5, FeelsLikeBottomLabel1, FeelsLikeBottomLabel2, FeelsLikeBottomLabel3, FeelsLikeBottomLabel4, FeelsLikeBottomLabel5]
        
        for label in secondLabels {
            label?.text = ""
        }
        
    }
    
    func updateViewForToday(_ hourly: [Hourly]) {
        updateHours(hourly: hourly)
    }
    
    func updateViewForWeekly(_ daily: [Daily]) {
        updateDays(daily: daily)
    }
    
    func getSelectedTitle() -> String {
        let index = segmentedControl.selectedSegmentIndex
        let title = segmentedControl.titleForSegment(at: index) ?? ""
        
        return title
        
    }
    
    func updateHours(hourly: [Hourly]) {
        let topLabels = [FeelsLikeTopLabel1, FeelsLikeTopLabel2, FeelsLikeTopLabel3, FeelsLikeTopLabel4,
                         FeelsLikeTopLabel5],
            bottomLabels = [FeelsLikeBottomLabel1, FeelsLikeBottomLabel2, FeelsLikeBottomLabel3,
                            FeelsLikeBottomLabel4, FeelsLikeBottomLabel5]
        
        for i in 0...4 {
            
            let hour = hourly[i + 1]
            let date = Date(timeIntervalSince1970: Double(hour.dt))
            let hourString = Date.getHourFrom(date: date)
            let feelsLikeData = hour.feels_like
            
            topLabels[i]?.text = hourString
            bottomLabels[i]?.text = "\(Int(feelsLikeData))°F"
        }
        
    }
    
    func updateDays(daily: [Daily]) {
        let topLabels = [FeelsLikeTopLabel1, FeelsLikeTopLabel2, FeelsLikeTopLabel3, FeelsLikeTopLabel4,
                         FeelsLikeTopLabel5],
            bottomLabels = [FeelsLikeBottomLabel1, FeelsLikeBottomLabel2, FeelsLikeBottomLabel3,
                            FeelsLikeBottomLabel4, FeelsLikeBottomLabel5]
        
        for i in 0...4 {
            
            let day = daily[i + 1]
            let date = Date(timeIntervalSince1970: Double(day.dt))
            let dayString = Date.getDayOfWeekFrom(date: date)
            let feelsLikeData = day.feels_like
            
            topLabels[i]?.text = dayString
            bottomLabels[i]?.text = "\(feelsLikeData)°F"
        }
    }
    
}





