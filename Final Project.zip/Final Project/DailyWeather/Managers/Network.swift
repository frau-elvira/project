//
//  Network.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 19.12.21.
//

import Foundation

class NetworkService {
    static let shared = NetworkService()
    
    //rename variables
    let apiKey = "34ccac0a6217fe65dd90706580613fd9"
    var urlLat = "60.99"
    var urlLong = "30.0"
    var urlGetCall = ""
    let urlData = "https://api.openweathermap.org/data/2.5"
    
    let session = URLSession(configuration: .default)
    
    func buildURL() -> String {
        "\(urlData)/onecall?lat=" + urlLat + "&lon=" + urlLong + "&units=imperial" + "&appid=" + apiKey
    }
    
    func setLatitude(_ latitude: String) {
        urlLat = latitude
    }
    
    func setLatitude(_ latitude: Double) {
        setLatitude(String(latitude))
    }
    
    func setLongitude(_ longitude: String) {
        urlLong = longitude
    }
    
    func setLongitude(_ longitude: Double) {
        setLongitude(String(longitude))
    }
    
    func getWeather(onSuccess: @escaping (Result) -> Void, onError: @escaping (String) -> Void) {
        guard let url = URL(string: buildURL()) else {
            onError("Error building URL")
            return
        }
        
        let task = session.dataTask(with: url) { (data, response, error) in
            
            DispatchQueue.main.async {
                if let error = error {
                    onError(error.localizedDescription)
                    return
                }
                
                guard let data = data, let response = response as? HTTPURLResponse else {
                    onError("Invalid data or response")
                    return
                }
                
                do {
                    if response.statusCode == 200 {
                        let items = try JSONDecoder().decode(Result.self, from: data)
                        onSuccess(items)
                    } else {
                        onError("Response wasn't 200. It was: " + "\n\(response.statusCode)")
                    }
                } catch {
                    onError(error.localizedDescription)
                }
            }
            
        }
        task.resume()
    }
    
}

