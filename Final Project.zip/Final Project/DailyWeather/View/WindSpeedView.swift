//
//  WindSpeedView.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 20.12.21.
//

import UIKit

class WindSpeedView: DesignView {
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var windSpeedLabel: UILabel!
    
    @IBOutlet weak var WindSpeedTopLabel1: UILabel!
    @IBOutlet weak var WindSpeedTopLabel2: UILabel!
    @IBOutlet weak var WindSpeedTopLabel3: UILabel!
    @IBOutlet weak var WindSpeedTopLabel4: UILabel!
    @IBOutlet weak var WindSpeedTopLabel5: UILabel!
    
    
    @IBOutlet weak var WindSpeedBottomLabel1: UILabel!
    @IBOutlet weak var WindSpeedBottomLabel2: UILabel!
    @IBOutlet weak var WindSpeedBottomLabel3: UILabel!
    @IBOutlet weak var WindSpeedBottomLabel4: UILabel!
    @IBOutlet weak var WindSpeedBottomLabel5: UILabel!
    
    func clear() {
        let secondLabels = [WindSpeedTopLabel1, WindSpeedTopLabel2, WindSpeedTopLabel3, WindSpeedTopLabel4, WindSpeedTopLabel5, WindSpeedBottomLabel1, WindSpeedBottomLabel2, WindSpeedBottomLabel3, WindSpeedBottomLabel4, WindSpeedBottomLabel5]
        
        for label in secondLabels {
            label?.text = ""
        }
        
    }
    
    func updateViewForToday(_ hourly: [Hourly]) {
        updateHours(hourly: hourly)
    }
    
    func updateViewForWeekly(_ daily: [Daily]) {
        updateDays(daily: daily)
    }
    
    func getSelectedTitle() -> String {
        let index = segmentedControl.selectedSegmentIndex
        let title = segmentedControl.titleForSegment(at: index) ?? ""
        
        return title
        
    }
    
    func updateHours(hourly: [Hourly]) {
        let topLabels = [WindSpeedTopLabel1, WindSpeedTopLabel2, WindSpeedTopLabel3, WindSpeedTopLabel4,
                         WindSpeedTopLabel5],
            bottomLabels = [WindSpeedBottomLabel1, WindSpeedBottomLabel2, WindSpeedBottomLabel3,
                            WindSpeedBottomLabel4, WindSpeedBottomLabel5]
        
        for i in 0...4 {
            
            let hour = hourly[i + 1]
            let date = Date(timeIntervalSince1970: Double(hour.dt))
            let hourString = Date.getHourFrom(date: date)
            let windSpeedData = hour.wind_speed
            
            topLabels[i]?.text = hourString
            bottomLabels[i]?.text = "\(Int(windSpeedData.rounded())) km/h"
        }
        
    }
    
    func updateDays(daily: [Daily]) {
        let topLabels = [WindSpeedTopLabel1, WindSpeedTopLabel2, WindSpeedTopLabel3, WindSpeedTopLabel4,
                         WindSpeedTopLabel5],
            bottomLabels = [WindSpeedBottomLabel1, WindSpeedBottomLabel2, WindSpeedBottomLabel3,
                            WindSpeedBottomLabel4, WindSpeedBottomLabel5]
        
        for i in 0...4 {
            
            let day = daily[i + 1]
            let date = Date(timeIntervalSince1970: Double(day.dt))
            let dayString = Date.getDayOfWeekFrom(date: date)
            let windSpeedData = day.wind_speed
            
            topLabels[i]?.text = dayString
            bottomLabels[i]?.text = "\(Int(windSpeedData.rounded())) km/h"
        }
    }
    
}



