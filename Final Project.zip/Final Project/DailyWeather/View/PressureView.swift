//
//  PressureView.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 20.12.21.
//

import UIKit

class PressureView: DesignView {
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var pressureLabel: UILabel!
    
    @IBOutlet weak var pressureTopLabel1: UILabel!
    @IBOutlet weak var pressureTopLabel2: UILabel!
    @IBOutlet weak var pressureTopLabel3: UILabel!
    @IBOutlet weak var pressureTopLabel4: UILabel!
    @IBOutlet weak var pressureTopLabel5: UILabel!
    
    @IBOutlet weak var pressureBottomLabel1: UILabel!
    @IBOutlet weak var pressureBottomLabel2: UILabel!
    @IBOutlet weak var pressureBottomLabel3: UILabel!
    @IBOutlet weak var pressureBottomLabel4: UILabel!
    @IBOutlet weak var pressureBottomLabel5: UILabel!
    
   // private let pressureText = NSLocalizedString("pressure_message_key", comment: "")
    
   // override func viewDidLoad() {
     //   super.viewDidLoad()
        
       // pressureLabel.text = pressureText
    //}
    
    func clear() {
        let secondLabels = [pressureTopLabel1, pressureTopLabel2, pressureTopLabel3, pressureTopLabel4, pressureTopLabel5, pressureBottomLabel1, pressureBottomLabel2, pressureBottomLabel3, pressureBottomLabel4, pressureBottomLabel5]
        
        
        for label in secondLabels {
            label?.text = ""
        }
        
    }
    
    
    func updateViewForToday(_ hourly: [Hourly]) {
        updateHours(hourly: hourly)
    }
    
    func updateViewForWeekly(_ daily: [Daily]) {
        updateDays(daily: daily)
    }
    
    func getSelectedTitle() -> String {
        let index = segmentedControl.selectedSegmentIndex
        let title = segmentedControl.titleForSegment(at: index) ?? ""
        
        return title
        
    }
    
    func updateHours(hourly: [Hourly]) {
        let topLabels = [pressureTopLabel1, pressureTopLabel2, pressureTopLabel3, pressureTopLabel4,
                         pressureTopLabel5],
            bottomLabels = [pressureBottomLabel1, pressureBottomLabel2, pressureBottomLabel3,
                            pressureBottomLabel4, pressureBottomLabel5]
        
        for i in 0...4 {
            
            let hour = hourly[i + 1]
            let date = Date(timeIntervalSince1970: Double(hour.dt))
            let hourString = Date.getHourFrom(date: date)
            let pressureData = hour.pressure
            
            topLabels[i]?.text = hourString
            bottomLabels[i]?.text = "\(pressureData) hPa"
        }
        
    }
    
    func updateDays(daily: [Daily]) {
        let topLabels = [pressureTopLabel1, pressureTopLabel2, pressureTopLabel3, pressureTopLabel4,
                         pressureTopLabel5],
            bottomLabels = [pressureBottomLabel1, pressureBottomLabel2, pressureBottomLabel3,
                            pressureBottomLabel4, pressureBottomLabel5]
        
        for i in 0...4 {
            
            let day = daily[i + 1]
            let date = Date(timeIntervalSince1970: Double(day.dt))
            let dayString = Date.getDayOfWeekFrom(date: date)
            let pressureData = day.pressure
            
            topLabels[i]?.text = dayString
            bottomLabels[i]?.text = "\(pressureData) hPa"
        }
    }
    
    
}

