//
//  SecondViewController.swift
//  DailyWeather
//
//  Created by Frau Elvira Herzogin von Sachsen on 20.12.21.
//

import UIKit
import MapKit

class PressureViewController: UIViewController, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var pressureView: PressureView!
    @IBOutlet weak var humidityView: HumidityView!
    @IBOutlet weak var windSpeedView: WindSpeedView!
    
    @IBOutlet weak var nextButton: UIButton!
    
   // private let humidityText = NSLocalizedString("humidity_message_key", comment: "")
  //  private let windSpeedText = NSLocalizedString("wind_speed_message_key", comment: "")
    
    
    @IBAction func forNextButton(_ sender: Any) {
        let cloudsViewController = storyboard?.instantiateViewController(withIdentifier: "cloudsView") as! CloudsViewController
        
        navigationController?.pushViewController(cloudsViewController, animated: true)
    }
    
    
    var city: String?
    var weatherResult: Result?
    var locationManger: CLLocationManager!
    var currentlocation: CLLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        clearAll()
        getLocation()
    }
    
    func clearAll() {
        pressureView.clear()
        humidityView.clear()
        windSpeedView.clear()
    }
    
    func getWeather() {
        NetworkService.shared.getWeather(onSuccess: { (result) in
            self.weatherResult = result
            
            self.weatherResult?.sortDailyArray()
            self.weatherResult?.sortHourlyArray()
            
            self.updateViews()
            
        }) { (errorMessage) in
            debugPrint(errorMessage)
        }
    }
    
    func updateViews() {
        //updateTopView()
        updateBottomView()
    }
    
    // func updateTopView() {
    //   guard let weatherResult = weatherResult else {
    //     return
    //}
    // }
    
    func updateBottomView() {
        guard let weatherResult = weatherResult else {
            return
        }
        
        let title = pressureView.getSelectedTitle()
        
        if title == "Today" {
            pressureView.updateViewForToday(weatherResult.hourly)
        } else if title == "Weekly" {
            pressureView.updateViewForWeekly(weatherResult.daily)
        }
        
        
        let humidityTitle = humidityView.getSelectedTitle()
        
        if humidityTitle == "Today" {
            humidityView.updateViewForToday(weatherResult.hourly)
        } else if humidityTitle == "Weekly" {
            humidityView.updateViewForWeekly(weatherResult.daily)
        }
        
        let windSpeedTitle = windSpeedView.getSelectedTitle()
        
        if windSpeedTitle == "Today" {
            windSpeedView.updateViewForToday(weatherResult.hourly)
        } else if windSpeedTitle == "Weekly" {
            windSpeedView.updateViewForWeekly(weatherResult.daily)
        }
    }
    
    
    func getLocation() {
        
        if (CLLocationManager.locationServicesEnabled()) {
            locationManger = CLLocationManager()
            locationManger.delegate = self
            locationManger.desiredAccuracy = kCLLocationAccuracyBest
            locationManger.requestWhenInUseAuthorization()
            locationManger.requestLocation()
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            self.currentlocation = location
            
            let latitude: Double = self.currentlocation!.coordinate.latitude
            let longitude: Double = self.currentlocation!.coordinate.longitude
            
            NetworkService.shared.setLatitude(latitude)
            NetworkService.shared.setLongitude(longitude)
            
            let geocoder = CLGeocoder()
            geocoder.reverseGeocodeLocation(location) { (placemarks, error) in
                if let error = error {
                    debugPrint(error.localizedDescription)
                }
                if let placemarks = placemarks {
                    if placemarks.count > 0 {
                        let placemark = placemarks[0]
                        if let city = placemark.locality {
                            self.city = city
                        }
                    }
                }
            }
            
            getWeather()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        debugPrint(error.localizedDescription)
    }
    
    @IBAction func onSegmentControllTap(_ sender: UIButton) {
        clearAll()
        getLocation()
    }
    
    @IBAction func todayWeeklyValueChanged(_ sender: UISegmentedControl) {
        clearAll()
        updateViews()
    }
}

